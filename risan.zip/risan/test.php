<!DOCTYPE html>
<html>
<head>
	<title>Test</title>
	<script type="text/javascript" src="script.js"></script>
</head>
<body>

</body>
</html>